The WANswitch atomic model needs WANswitch.ev event file as input.

To run the simulation for testing the model, run the WANswitch.bat file.