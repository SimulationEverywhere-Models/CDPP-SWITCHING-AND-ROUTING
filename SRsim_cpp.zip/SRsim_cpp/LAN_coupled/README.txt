The LANcoupled model needs LANcoupled.ev event file as input.

To run the simulation for testing the model, run the LANcoupled.bat file.