The WANcoupled model needs WANcoupled.ev event file as input.

To run the simulation for testing the model, run the WANcoupled.bat file.