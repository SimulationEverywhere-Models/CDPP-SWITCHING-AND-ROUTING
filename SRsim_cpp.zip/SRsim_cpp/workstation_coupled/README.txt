The workstation coupled model needs workstation.ev event file as input.

To run the simulation for testing the model, run the workstation.bat file.