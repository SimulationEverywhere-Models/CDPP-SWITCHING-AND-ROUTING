The source atomic model does not need an event file as it has no inputs.

To run the simulation for testing the model, run the source.bat file.