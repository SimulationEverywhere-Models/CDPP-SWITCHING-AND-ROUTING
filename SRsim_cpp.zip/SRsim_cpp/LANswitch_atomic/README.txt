The LANswitch_atomic model needs LANswitch.ev event file as input.

To run the simulation for testing the model, run the LANswitch.bat file.