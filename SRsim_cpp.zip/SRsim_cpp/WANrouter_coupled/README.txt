The WANrouter_coupled model needs WANrouter_coupled.ev event file as input.

To run the simulation for testing the model, run the WANrouter_coupled.bat file.