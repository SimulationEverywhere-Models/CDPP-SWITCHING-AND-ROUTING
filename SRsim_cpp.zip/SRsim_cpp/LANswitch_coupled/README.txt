The LANswitch_coupled model needs LANswitch_coupled.ev event file as input.

To run the simulation for testing the model, run the LANswitch_coupled.bat file.