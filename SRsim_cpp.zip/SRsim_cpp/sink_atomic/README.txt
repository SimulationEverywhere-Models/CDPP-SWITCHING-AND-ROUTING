The sink atomic model needs sink.ev event file as input.

To run the simulation for testing the model, run the sink.bat file.